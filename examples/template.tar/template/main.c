
#include <stdint.h>
#include <stdio.h>

int_fast8_t main(size_t argc, char **argv)
{
  puts("Hello world !");
}

